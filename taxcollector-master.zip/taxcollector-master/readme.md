[ ![Codeship Status for VictorAlagwu/taxcollector](https://app.codeship.com/projects/b2fdf630-4d0d-0136-50e2-169c3cf793fe/status?branch=master)](https://app.codeship.com/projects/293297)

# Tax Collection

## About Tax Collection

Tax Collection and Management System 
A System that allow users to generate their tax invoice and make payment online using the paystack API